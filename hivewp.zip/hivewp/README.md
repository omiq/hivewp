# HiveWP WordPress Plugin for Hive Blockchain Community Bloggers

This WordPress plugin allows you to syndicate your Hive blog posts to your WordPress websites on a schedule and using filter criteria:

<img width="1089" alt="Screen Shot 2022-04-30 at 17 44 03" src="https://user-images.githubusercontent.com/3143825/166126484-ee13bdfd-dd97-4b4e-b0cf-0743932d97ee.png">


Requires [Parsedown PHP library](https://github.com/erusev/parsedown) 
